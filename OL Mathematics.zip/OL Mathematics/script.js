const circles = document.querySelectorAll(".circle");
const progressBar = document.querySelector(".indicator");
const buttons = document.querySelectorAll("button");

let currentStep = 0;
let allStepsCompleted = false;

const updateSteps = (e) => {
  if (e.target.id === "next") {
    currentStep++;
    if (currentStep >= circles.length) {
      currentStep = circles.length;
      allStepsCompleted = true;
      buttons[1].disabled = true;
    }
    buttons[0].disabled = false;
  } else if (e.target.id === "prev") {
    currentStep--;
    if (currentStep === 0) {
      buttons[0].disabled = true;
    }
    buttons[1].disabled = false;
  }

  circles.forEach((circle, index) => {
    if (index < currentStep) {
      circle.classList.add("active");
    } else {
      circle.classList.remove("active");
    }
  });

  progressBar.style.width = `${(currentStep / circles.length) * 100}%`;

  if (allStepsCompleted && currentStep === circles.length) {
    buttons[1].disabled = true;
  } else if (currentStep === 1) {
    buttons[0].disabled = false;
  }
};

buttons.forEach((button) => {
  button.addEventListener("click", updateSteps);
});

// set currentStep from localStorage when the page loads
window.addEventListener("load", () => {
  circles.forEach((circle, index) => {
    if (index < currentStep) {
      circle.classList.add("active");
    }
  });

  progressBar.style.width = `${(currentStep / circles.length) * 100}%`;

  if (currentStep > 0) {
    buttons[0].disabled = false;
  }
});