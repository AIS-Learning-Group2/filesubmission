<?php
if (isset($_FILES['file'])) {
  $file = $_FILES['file'];
  $fileName = $file['name'];
  $fileTmpName = $file['tmp_name'];
  $fileSize = $file['size'];
  $fileError = $file['error'];
  $fileType = $file['type'];

  $fileExt = explode('.', $fileName);
  $fileActualExt = strtolower(end($fileExt));

  $allowed = array('jpg', 'jpeg', 'png', 'pdf', 'docx', 'doc');

  if (in_array($fileActualExt, $allowed)) {
    if ($fileError === 0) {
      if ($fileSize < 1000000) {
        $fileNameNew = uniqid('', true) . '.' . $fileActualExt;
        $fileDestination = 'uploads/lesson2/' . $fileNameNew;
        move_uploaded_file($fileTmpName, $fileDestination);
        echo '<p class="uploaded-file">Successfully uploaded ' . $fileName . '</p>';
      } else {
        echo '<p class="error">File is too big!</p>';
      }
    } else {
      echo '<p class="error">There was an error uploading your file!</p>';
    }
  } else {
    echo '<p class="error">You cannot upload files of this type!</p>';
  }
}
?>