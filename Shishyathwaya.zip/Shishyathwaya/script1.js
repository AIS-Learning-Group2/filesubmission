const circles = document.querySelectorAll(".circle");
const progressBar = document.querySelector(".indicator");
const buttons = document.querySelectorAll("button");

let currentStep = localStorage.getItem("currentStep") || 0; // get current step from localStorage or set to 0

const updateSteps = (e) => {
  if (e.target.id === "next") {
    currentStep++;
    if (currentStep >= circles.length) {
      currentStep = circles.length;
      buttons[1].disabled = true;
    }
    buttons[0].disabled = false;
  } else if (e.target.id === "prev" && currentStep > 0) {
    currentStep--;
    if (currentStep === 0) {
      buttons[0].disabled = true;
    }
    buttons[1].disabled = false;
  }

  circles.forEach((circle, index) => {
    circle.classList.toggle("active", index < currentStep);
  });

  progressBar.style.width = `${(currentStep / circles.length) * 100}%`;

  if (currentStep === 1) {
    buttons[0].disabled = false;
  }

  localStorage.setItem("currentStep", currentStep); // store current step in localStorage
};

buttons.forEach((button) => {
  button.addEventListener("click", updateSteps);
});

// set currentStep from localStorage when the page loads
window.addEventListener("load", () => {
  circles.forEach((circle, index) => {
    circle.classList.toggle("active", index < currentStep);
  });

  progressBar.style.width = `${(currentStep / circles.length) * 100}%`;

  if (currentStep > 0) {
    buttons[0].disabled = false;
  }
});