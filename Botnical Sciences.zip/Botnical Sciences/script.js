const lesson1Form = document.getElementById('lesson1-form');
const lesson2Form = document.getElementById('lesson2-form');

// Add event listener to file inputs
document.getElementById('file1').addEventListener('change', function() {
  lesson1Form.submit();
});

document.getElementById('file2').addEventListener('change', function() {
  lesson2Form.submit();
});

// Add event listener to form submissions
lesson1Form.addEventListener('submit', function(event) {
  event.preventDefault();

  const formData = new FormData(lesson1Form);

  // Send file to server
  fetch('php/upload1.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    const uploadedSection = document.getElementById('uploaded1');
    uploadedSection.innerHTML = data;
  });
});

lesson2Form.addEventListener('submit', function(event) {
  event.preventDefault();

  const formData = new FormData(lesson2Form);

  // Send file to server
  fetch('php/upload2.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    const uploadedSection = document.getElementById('uploaded2');
    uploadedSection.innerHTML = data;
  });
});